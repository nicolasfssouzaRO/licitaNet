/**
 * Módulo principal da aplicação SaaS
 * Inicializa e gerencia os componentes da aplicação
 */

// Importa os módulos necessários
const comprasnetAPI = require('./api');
const licitacoesUI = require('./js/licitacoes');
const contratosUI = require('./js/contratos');
const dashboardUI = require('./js/dashboard');

// Configurações da aplicação
const app = {
    // Inicializa a aplicação
    init() {
        // Configura o menu de navegação
        this.setupNavigation();
        
        // Inicializa o módulo ativo (padrão: dashboard)
        this.activateModule('dashboard');
        
        console.log('Aplicação SaaS de integração com Compranet inicializada com sucesso!');
    },
    
    // Configura a navegação entre módulos
    setupNavigation() {
        const navLinks = document.querySelectorAll('.nav-link');
        
        navLinks.forEach(link => {
            link.addEventListener('click', (event) => {
                event.preventDefault();
                
                // Remove a classe ativa de todos os links
                navLinks.forEach(l => l.classList.remove('active'));
                
                // Adiciona a classe ativa ao link clicado
                link.classList.add('active');
                
                // Ativa o módulo correspondente
                const module = link.getAttribute('data-module');
                this.activateModule(module);
            });
        });
    },
    
    // Ativa um módulo específico
    activateModule(moduleName) {
        // Oculta todos os containers de módulos
        const moduleContainers = document.querySelectorAll('.module-container');
        moduleContainers.forEach(container => {
            container.style.display = 'none';
        });
        
        // Exibe o container do módulo selecionado
        const activeContainer = document.getElementById(`${moduleName}-container`);
        if (activeContainer) {
            activeContainer.style.display = 'block';
        }
        
        // Inicializa o módulo selecionado
        switch (moduleName) {
            case 'dashboard':
                dashboardUI.init();
                break;
            case 'licitacoes':
                licitacoesUI.init();
                break;
            case 'contratos':
                contratosUI.init();
                break;
            default:
                console.error(`Módulo "${moduleName}" não encontrado`);
        }
    }
};

// Inicializa a aplicação quando o DOM estiver carregado
document.addEventListener('DOMContentLoaded', () => {
    app.init();
});

// Exporta o módulo da aplicação
module.exports = app;
